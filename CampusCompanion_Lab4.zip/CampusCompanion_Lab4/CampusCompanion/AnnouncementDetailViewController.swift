import UIKit
class AnnouncementDetailViewController: UIViewController {
    @IBOutlet weak var detailsLabel: UILabel!
    var announcementTitle = ""
    var announcementDate = ""
    var announcementCategory = ""
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Announcement"
        detailsLabel.text = "\(announcementTitle)\n\n\(announcementCategory) • \(announcementDate)"
    }
}
