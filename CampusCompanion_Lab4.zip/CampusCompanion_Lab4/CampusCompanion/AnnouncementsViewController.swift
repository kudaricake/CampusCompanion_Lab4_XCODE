import UIKit
import CoreData

class AnnouncementsViewController: UITableViewController {
    private var announcements: [CampusAnnouncement] = []
    private var context: NSManagedObjectContext {
        (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Campus Announcements"
        seedInitialAnnouncementsIfNeeded()
        loadAnnouncements()
    }

    // Seed only when the store is empty; do not duplicate rows on subsequent launches.
    private func seedInitialAnnouncementsIfNeeded() {
        let request: NSFetchRequest<CampusAnnouncement> = CampusAnnouncement.fetchRequest()
        do {
            guard try context.count(for: request) == 0 else { return }
            let samples: [(String, String, String)] = [
                ("Enrollment Period Extended", "August 3, 2026", "Registrar"),
                ("Library Hours Extended for Finals", "August 5, 2026", "Library"),
                ("Career Fair 2026", "August 10, 2026", "Career Center"),
                ("Student Council Elections", "August 14, 2026", "Student Affairs"),
                ("Campus Wi-Fi Maintenance Notice", "August 16, 2026", "IT Services"),
                ("Intramural Sports Sign-Up", "August 20, 2026", "Athletics")
            ]
            for (title, date, category) in samples {
                let item = CampusAnnouncement(context: context)
                item.title = title; item.date = date; item.category = category
            }
            try context.save()
        } catch { NSLog("Unable to seed announcements: \(error)") }
    }

    private func loadAnnouncements() {
        let request: NSFetchRequest<CampusAnnouncement> = CampusAnnouncement.fetchRequest()
        do {
            announcements = try context.fetch(request)
            // Dates are stored as strings in the required model; parse them for chronological order.
            let formatter = DateFormatter()
            formatter.locale = Locale(identifier: "en_US_POSIX")
            formatter.dateFormat = "MMMM d, yyyy"
            announcements.sort {
                (formatter.date(from: $0.date ?? "") ?? .distantFuture) < (formatter.date(from: $1.date ?? "") ?? .distantFuture)
            }
            tableView.reloadData()
        } catch { NSLog("Fetch failed: \(error)") }
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int { announcements.count }
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "AnnouncementCell", for: indexPath)
        let item = announcements[indexPath.row]
        cell.textLabel?.text = item.title
        cell.detailTextLabel?.text = "\(item.category ?? "") • \(item.date ?? "")"
        return cell
    }

    @IBAction func addAnnouncementTapped(_ sender: UIBarButtonItem) {
        let alert = UIAlertController(title: "New Announcement", message: "Enter a title and category.", preferredStyle: .alert)
        alert.addTextField { $0.placeholder = "Title" }
        alert.addTextField { $0.placeholder = "Category" }
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel))
        alert.addAction(UIAlertAction(title: "Save", style: .default) { [weak self, weak alert] _ in
            guard let self = self,
                  let title = alert?.textFields?.first?.text?.trimmingCharacters(in: .whitespacesAndNewlines), !title.isEmpty,
                  let category = alert?.textFields?.last?.text?.trimmingCharacters(in: .whitespacesAndNewlines), !category.isEmpty else { return }
            let item = CampusAnnouncement(context: self.context)
            item.title = title
            item.category = category
            item.date = DateFormatter.localizedString(from: Date(), dateStyle: .long, timeStyle: .none)
            do { try self.context.save(); self.loadAnnouncements() }
            catch { self.context.rollback(); self.showError("Could not save announcement.") }
        })
        present(alert, animated: true)
    }

    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        guard editingStyle == .delete else { return }
        let item = announcements[indexPath.row]
        context.delete(item)
        do { try context.save(); announcements.remove(at: indexPath.row); tableView.deleteRows(at: [indexPath], with: .automatic) }
        catch { context.rollback(); showError("Could not delete announcement.") }
    }

    private func showError(_ message: String) {
        let alert = UIAlertController(title: "Error", message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default))
        present(alert, animated: true)
    }
}
