import UIKit
class DetailViewController: UIViewController {
    @IBOutlet weak var messageLabel: UILabel!
    var studentName = "Student"
    var notificationsEnabled = false
    var selectedRole = "Student"
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Campus Events"
        messageLabel.text = "Welcome, \(studentName)! (\(selectedRole))\nNotifications: \(notificationsEnabled ? "on" : "off")."
    }
}
